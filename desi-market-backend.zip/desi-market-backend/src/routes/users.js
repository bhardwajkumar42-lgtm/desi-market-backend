const express = require("express");
const { query } = require("../db");
const { verifyToken } = require("../middleware/auth");
const { asyncHandler, ApiError } = require("../middleware/errorHandler");

const router = express.Router();

router.get(
  "/:id",
  verifyToken,
  asyncHandler(async (req, res) => {
    const { rows } = await query(
      "SELECT id, mobile, name, role, village_id, is_verified, kyc_status, created_at FROM users WHERE id = $1",
      [req.params.id]
    );
    if (!rows[0]) throw new ApiError(404, "User not found");
    res.json({ user: rows[0] });
  })
);

router.patch(
  "/:id",
  verifyToken,
  asyncHandler(async (req, res) => {
    const targetId = Number(req.params.id);
    if (req.user.id !== targetId && req.user.role !== "admin") {
      throw new ApiError(403, "आप केवल अपनी प्रोफाइल बदल सकते हैं");
    }
    const { name, village_id } = req.body;
    const { rows } = await query(
      `UPDATE users SET name = COALESCE($1, name), village_id = COALESCE($2, village_id)
       WHERE id = $3 RETURNING id, mobile, name, role, village_id, is_verified, kyc_status`,
      [name, village_id, targetId]
    );
    if (!rows[0]) throw new ApiError(404, "User not found");
    res.json({ user: rows[0] });
  })
);

module.exports = router;
