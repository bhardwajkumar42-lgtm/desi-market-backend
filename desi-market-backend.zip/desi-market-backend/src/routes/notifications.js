const express = require("express");
const { query } = require("../db");
const { verifyToken } = require("../middleware/auth");
const { asyncHandler } = require("../middleware/errorHandler");

const router = express.Router();

router.get(
  "/",
  verifyToken,
  asyncHandler(async (req, res) => {
    const { rows } = await query(
      "SELECT * FROM notifications WHERE user_id = $1 ORDER BY created_at DESC LIMIT 100",
      [req.user.id]
    );
    res.json({ notifications: rows });
  })
);

router.patch(
  "/:id/read",
  verifyToken,
  asyncHandler(async (req, res) => {
    const { rows } = await query(
      "UPDATE notifications SET is_read = true WHERE id = $1 AND user_id = $2 RETURNING *",
      [req.params.id, req.user.id]
    );
    res.json({ notification: rows[0] });
  })
);

module.exports = router;
