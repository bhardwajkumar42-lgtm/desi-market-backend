/** Wraps an async route handler so thrown errors reach the error middleware. */
function asyncHandler(fn) {
  return function wrapped(req, res, next) {
    Promise.resolve(fn(req, res, next)).catch(next);
  };
}

class ApiError extends Error {
  constructor(statusCode, message) {
    super(message);
    this.statusCode = statusCode;
  }
}

// eslint-disable-next-line no-unused-vars
function errorHandler(err, req, res, next) {
  const statusCode = err.statusCode || 500;
  if (statusCode === 500) {
    // eslint-disable-next-line no-console
    console.error(err);
  }
  res.status(statusCode).json({
    error: true,
    message: err.message || "Internal server error",
  });
}

function notFoundHandler(req, res) {
  res.status(404).json({ error: true, message: "Route not found" });
}

module.exports = { asyncHandler, ApiError, errorHandler, notFoundHandler };
