const jwt = require("jsonwebtoken");
const { ApiError } = require("./errorHandler");

function signToken(user) {
  return jwt.sign(
    { id: user.id, mobile: user.mobile, role: user.role },
    process.env.JWT_SECRET,
    { expiresIn: process.env.JWT_EXPIRES_IN || "30d" }
  );
}

/** Requires a valid Bearer token; attaches decoded payload to req.user. */
function verifyToken(req, res, next) {
  const header = req.headers.authorization || "";
  const [scheme, token] = header.split(" ");
  if (scheme !== "Bearer" || !token) {
    return next(new ApiError(401, "Missing or malformed Authorization header"));
  }
  try {
    req.user = jwt.verify(token, process.env.JWT_SECRET);
    next();
  } catch (err) {
    next(new ApiError(401, "Invalid or expired token"));
  }
}

/** Optionally attaches req.user if a valid token is present, but never blocks the request. */
function optionalAuth(req, res, next) {
  const header = req.headers.authorization || "";
  const [scheme, token] = header.split(" ");
  if (scheme === "Bearer" && token) {
    try {
      req.user = jwt.verify(token, process.env.JWT_SECRET);
    } catch (err) {
      // ignore invalid token for optional auth
    }
  }
  next();
}

/** Restricts a route to one or more roles. Use after verifyToken. */
function requireRole(...roles) {
  return function (req, res, next) {
    if (!req.user) return next(new ApiError(401, "Authentication required"));
    if (!roles.includes(req.user.role)) {
      return next(new ApiError(403, "You do not have permission to do this"));
    }
    next();
  };
}

module.exports = { signToken, verifyToken, optionalAuth, requireRole };
