-- =========================================================
-- DESI MARKET — PostgreSQL Schema (Step 2)
-- Matches the table list from the project spec, section 25.
-- Run via `npm run db:setup` or psql -f database/schema.sql
-- =========================================================

-- ---------- Extensions ----------
CREATE EXTENSION IF NOT EXISTS pgcrypto; -- for gen_random_uuid() if ever needed

-- ---------- Enums ----------
DO $$ BEGIN
  CREATE TYPE user_role AS ENUM ('customer','seller','worker','delivery','field_partner','admin');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TYPE kyc_status AS ENUM ('pending','verified','rejected');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TYPE listing_status AS ENUM ('pending','live','suspended');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TYPE availability_status AS ENUM ('available','busy','unavailable');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TYPE order_status AS ENUM ('placed','confirmed','packed','out_for_delivery','delivered','cancelled');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TYPE booking_status AS ENUM ('requested','accepted','on_the_way','started','completed','cancelled');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TYPE payment_status AS ENUM ('pending','paid','failed','refunded');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TYPE delivery_status AS ENUM ('new','accepted','picked_up','on_the_way','delivered');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TYPE consent_status AS ENUM ('pending','consented','declined');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

-- ---------- Geography hierarchy ----------
CREATE TABLE IF NOT EXISTS states (
  id SERIAL PRIMARY KEY,
  name TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS districts (
  id SERIAL PRIMARY KEY,
  state_id INT REFERENCES states(id) ON DELETE CASCADE,
  name TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS blocks (
  id SERIAL PRIMARY KEY,
  district_id INT REFERENCES districts(id) ON DELETE CASCADE,
  name TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS panchayats (
  id SERIAL PRIMARY KEY,
  block_id INT REFERENCES blocks(id) ON DELETE CASCADE,
  name TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS villages (
  id SERIAL PRIMARY KEY,
  panchayat_id INT REFERENCES panchayats(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  latitude NUMERIC(9,6),
  longitude NUMERIC(9,6)
);

-- ---------- Users ----------
CREATE TABLE IF NOT EXISTS users (
  id SERIAL PRIMARY KEY,
  mobile VARCHAR(15) UNIQUE NOT NULL,
  name TEXT,
  role user_role NOT NULL DEFAULT 'customer',
  village_id INT REFERENCES villages(id),
  is_verified BOOLEAN DEFAULT FALSE,
  kyc_status kyc_status DEFAULT 'pending',
  created_at TIMESTAMPTZ DEFAULT now()
);

-- ---------- Categories & skills ----------
CREATE TABLE IF NOT EXISTS product_categories (
  id SERIAL PRIMARY KEY,
  code TEXT UNIQUE NOT NULL,
  name_hi TEXT NOT NULL,
  name_en TEXT,
  emoji TEXT
);

CREATE TABLE IF NOT EXISTS service_categories (
  id SERIAL PRIMARY KEY,
  code TEXT UNIQUE NOT NULL,
  name_hi TEXT NOT NULL,
  name_en TEXT,
  emoji TEXT
);

CREATE TABLE IF NOT EXISTS skills (
  id SERIAL PRIMARY KEY,
  service_category_id INT REFERENCES service_categories(id) ON DELETE CASCADE,
  name TEXT NOT NULL
);

-- ---------- Sellers & products ----------
CREATE TABLE IF NOT EXISTS sellers (
  id SERIAL PRIMARY KEY,
  user_id INT REFERENCES users(id) UNIQUE,
  shop_name TEXT NOT NULL,
  owner_name TEXT,
  village_id INT REFERENCES villages(id),
  latitude NUMERIC(9,6),
  longitude NUMERIC(9,6),
  opens_at TIME,
  closes_at TIME,
  rating NUMERIC(2,1) DEFAULT 0,
  is_verified BOOLEAN DEFAULT FALSE,
  status listing_status DEFAULT 'pending',
  created_at TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE IF NOT EXISTS products (
  id SERIAL PRIMARY KEY,
  seller_id INT REFERENCES sellers(id) ON DELETE CASCADE,
  category_id INT REFERENCES product_categories(id),
  name TEXT NOT NULL,
  description TEXT,
  price NUMERIC(10,2) NOT NULL,
  unit TEXT,
  stock INT DEFAULT 0,
  image_url TEXT,
  is_active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- ---------- Service providers ----------
CREATE TABLE IF NOT EXISTS service_providers (
  id SERIAL PRIMARY KEY,
  user_id INT REFERENCES users(id) UNIQUE,
  name TEXT NOT NULL,
  service_category_id INT REFERENCES service_categories(id),
  village_id INT REFERENCES villages(id),
  latitude NUMERIC(9,6),
  longitude NUMERIC(9,6),
  experience_years INT DEFAULT 0,
  rate NUMERIC(10,2),
  rate_type TEXT DEFAULT 'per_day', -- per_day | per_hour | per_visit | quotation
  team_size INT DEFAULT 1,
  service_area_km INT DEFAULT 5,
  availability availability_status DEFAULT 'available',
  rating NUMERIC(2,1) DEFAULT 0,
  jobs_completed INT DEFAULT 0,
  is_verified BOOLEAN DEFAULT FALSE,
  status listing_status DEFAULT 'pending',
  created_at TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE IF NOT EXISTS provider_skills (
  provider_id INT REFERENCES service_providers(id) ON DELETE CASCADE,
  skill_id INT REFERENCES skills(id) ON DELETE CASCADE,
  PRIMARY KEY (provider_id, skill_id)
);

CREATE TABLE IF NOT EXISTS provider_portfolio (
  id SERIAL PRIMARY KEY,
  provider_id INT REFERENCES service_providers(id) ON DELETE CASCADE,
  image_url TEXT,
  caption TEXT,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- ---------- Orders ----------
CREATE TABLE IF NOT EXISTS orders (
  id SERIAL PRIMARY KEY,
  customer_id INT REFERENCES users(id),
  seller_id INT REFERENCES sellers(id),
  status order_status DEFAULT 'placed',
  total_amount NUMERIC(10,2) NOT NULL,
  delivery_address TEXT,
  payment_status payment_status DEFAULT 'pending',
  created_at TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE IF NOT EXISTS order_items (
  id SERIAL PRIMARY KEY,
  order_id INT REFERENCES orders(id) ON DELETE CASCADE,
  product_id INT REFERENCES products(id),
  quantity INT NOT NULL CHECK (quantity > 0),
  price_at_order NUMERIC(10,2) NOT NULL
);

-- ---------- Bookings ----------
CREATE TABLE IF NOT EXISTS bookings (
  id SERIAL PRIMARY KEY,
  customer_id INT REFERENCES users(id),
  provider_id INT REFERENCES service_providers(id),
  status booking_status DEFAULT 'requested',
  scheduled_date DATE,
  scheduled_slot TEXT,
  problem_description TEXT,
  photo_url TEXT,
  location_text TEXT,
  quoted_amount NUMERIC(10,2),
  final_amount NUMERIC(10,2),
  created_at TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE IF NOT EXISTS booking_quotes (
  id SERIAL PRIMARY KEY,
  booking_id INT REFERENCES bookings(id) ON DELETE CASCADE,
  provider_id INT REFERENCES service_providers(id),
  amount NUMERIC(10,2),
  note TEXT,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- ---------- Payments & commission ----------
CREATE TABLE IF NOT EXISTS payments (
  id SERIAL PRIMARY KEY,
  order_id INT REFERENCES orders(id),
  booking_id INT REFERENCES bookings(id),
  amount NUMERIC(10,2) NOT NULL,
  method TEXT, -- upi | cod | card
  status payment_status DEFAULT 'pending',
  transaction_ref TEXT,
  created_at TIMESTAMPTZ DEFAULT now(),
  CHECK (order_id IS NOT NULL OR booking_id IS NOT NULL)
);

CREATE TABLE IF NOT EXISTS commissions (
  id SERIAL PRIMARY KEY,
  payment_id INT REFERENCES payments(id) ON DELETE CASCADE,
  percentage NUMERIC(5,2),
  amount NUMERIC(10,2),
  created_at TIMESTAMPTZ DEFAULT now()
);

-- ---------- Delivery ----------
CREATE TABLE IF NOT EXISTS deliveries (
  id SERIAL PRIMARY KEY,
  order_id INT REFERENCES orders(id),
  delivery_partner_id INT REFERENCES users(id),
  status delivery_status DEFAULT 'new',
  pickup_address TEXT,
  drop_address TEXT,
  distance_km NUMERIC(6,2),
  earning NUMERIC(10,2),
  created_at TIMESTAMPTZ DEFAULT now()
);

-- ---------- Chat ----------
CREATE TABLE IF NOT EXISTS conversations (
  id SERIAL PRIMARY KEY,
  customer_id INT REFERENCES users(id),
  provider_id INT REFERENCES users(id),
  booking_id INT REFERENCES bookings(id),
  created_at TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE IF NOT EXISTS messages (
  id SERIAL PRIMARY KEY,
  conversation_id INT REFERENCES conversations(id) ON DELETE CASCADE,
  sender_id INT REFERENCES users(id),
  message TEXT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- ---------- Reviews ----------
CREATE TABLE IF NOT EXISTS reviews (
  id SERIAL PRIMARY KEY,
  customer_id INT REFERENCES users(id),
  seller_id INT REFERENCES sellers(id),
  provider_id INT REFERENCES service_providers(id),
  order_id INT REFERENCES orders(id),
  booking_id INT REFERENCES bookings(id),
  rating INT CHECK (rating BETWEEN 1 AND 5),
  comment TEXT,
  created_at TIMESTAMPTZ DEFAULT now(),
  CHECK (seller_id IS NOT NULL OR provider_id IS NOT NULL)
);

-- ---------- Notifications ----------
CREATE TABLE IF NOT EXISTS notifications (
  id SERIAL PRIMARY KEY,
  user_id INT REFERENCES users(id),
  title TEXT,
  body TEXT,
  type TEXT,
  is_read BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- ---------- Verifications (KYC) ----------
CREATE TABLE IF NOT EXISTS verifications (
  id SERIAL PRIMARY KEY,
  user_id INT REFERENCES users(id),
  document_type TEXT,
  document_url TEXT,
  status kyc_status DEFAULT 'pending',
  reviewed_by INT REFERENCES users(id),
  created_at TIMESTAMPTZ DEFAULT now()
);

-- ---------- Add Partner (field-partner-created profiles) ----------
CREATE TABLE IF NOT EXISTS partner_referrals (
  id SERIAL PRIMARY KEY,
  referred_by INT REFERENCES users(id),
  name TEXT NOT NULL,
  mobile VARCHAR(15) NOT NULL,
  village_id INT REFERENCES villages(id),
  category TEXT,
  role TEXT,
  experience_years INT,
  rate NUMERIC(10,2),
  consent_status consent_status DEFAULT 'pending',
  otp_verified BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- ---------- Helpful indexes ----------
CREATE INDEX IF NOT EXISTS idx_products_category ON products(category_id);
CREATE INDEX IF NOT EXISTS idx_products_seller ON products(seller_id);
CREATE INDEX IF NOT EXISTS idx_providers_category ON service_providers(service_category_id);
CREATE INDEX IF NOT EXISTS idx_providers_village ON service_providers(village_id);
CREATE INDEX IF NOT EXISTS idx_sellers_village ON sellers(village_id);
CREATE INDEX IF NOT EXISTS idx_orders_customer ON orders(customer_id);
CREATE INDEX IF NOT EXISTS idx_bookings_customer ON bookings(customer_id);
CREATE INDEX IF NOT EXISTS idx_bookings_provider ON bookings(provider_id);
CREATE INDEX IF NOT EXISTS idx_messages_conversation ON messages(conversation_id);
CREATE INDEX IF NOT EXISTS idx_notifications_user ON notifications(user_id);
