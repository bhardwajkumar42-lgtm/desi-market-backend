/**
 * Runs database/schema.sql then database/seed.sql against DATABASE_URL.
 * Usage: npm run db:setup
 */
require("dotenv").config();
const fs = require("fs");
const path = require("path");
const { Pool } = require("pg");

async function main() {
  if (!process.env.DATABASE_URL) {
    console.error("❌ DATABASE_URL is not set. Copy .env.example to .env first.");
    process.exit(1);
  }

  const pool = new Pool({ connectionString: process.env.DATABASE_URL });
  const schemaPath = path.join(__dirname, "..", "database", "schema.sql");
  const seedPath = path.join(__dirname, "..", "database", "seed.sql");

  try {
    console.log("▶ Applying schema.sql ...");
    const schemaSql = fs.readFileSync(schemaPath, "utf8");
    await pool.query(schemaSql);
    console.log("✅ Schema applied.");

    console.log("▶ Applying seed.sql ...");
    const seedSql = fs.readFileSync(seedPath, "utf8");
    await pool.query(seedSql);
    console.log("✅ Seed data inserted.");

    console.log("🎉 Database setup complete.");
  } catch (err) {
    console.error("❌ Database setup failed:", err.message);
    process.exitCode = 1;
  } finally {
    await pool.end();
  }
}

main();
